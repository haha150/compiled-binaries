
compile: cl encode.c mmap-windows.c
usage:   encode loader.bin base64.txt