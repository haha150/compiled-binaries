/**
  BSD 3-Clause License

  Copyright (c) 2019, TheWover, Odzhan. All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright notice, this
    list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.

  * Neither the name of the copyright holder nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef BYPASS_H
#define BYPASS_H

// Disables Antimalware Scan Interface
BOOL DisableAMSI(PDONUT_INSTANCE);

// Disables Windows Lockdown Policy
BOOL DisableWLDP(PDONUT_INSTANCE);

// Disables ETW
BOOL DisableETW(PDONUT_INSTANCE);

// Use by BYPASS_WLDP_A
typedef enum _WLDP_HOST_ID {
    WLDP_HOST_ID_UNKNOWN = 0,
    WLDP_HOST_ID_GLOBAL = 1,
    WLDP_HOST_ID_VBA = 2,
    WLDP_HOST_ID_WSH = 3,
    WLDP_HOST_ID_POWERSHELL = 4,
    WLDP_HOST_ID_IE = 5,
    WLDP_HOST_ID_MSI = 6,
    WLDP_HOST_ID_MAX = 7
} WLDP_HOST_ID, *PWLDP_HOST_ID;

typedef struct _WLDP_HOST_INFORMATION {
    DWORD dwRevision;
    WLDP_HOST_ID dwHostId;
    PCWSTR szSource;
    HANDLE hSource;
} WLDP_HOST_INFORMATION, *PWLDP_HOST_INFORMATION;

// Used by BYPASS_ETW_B
typedef enum _SYSTEM_INFORMATION_CLASS {
    SystemBasicInformation,                // q: SYSTEM_BASIC_INFORMATION
    SystemProcessorInformation,            // q: SYSTEM_PROCESSOR_INFORMATION
    SystemPerformanceInformation,          // q: SYSTEM_PERFORMANCE_INFORMATION
    SystemTimeOfDayInformation,            // q: SYSTEM_TIMEOFDAY_INFORMATION
    SystemPathInformation,                 // not implemented
    SystemProcessInformation,              // q: SYSTEM_PROCESS_INFORMATION
    SystemCallCountInformation,            // q: SYSTEM_CALL_COUNT_INFORMATION
    SystemDeviceInformation,               // q: SYSTEM_DEVICE_INFORMATION
    SystemProcessorPerformanceInformation, // q: SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION
    SystemFlagsInformation,                // q: SYSTEM_FLAGS_INFORMATION
    SystemCallTimeInformation,   // not implemented // SYSTEM_CALL_TIME_INFORMATION // 10
    SystemModuleInformation,     // q: RTL_PROCESS_MODULES
    SystemLocksInformation,      // q: RTL_PROCESS_LOCKS
    SystemStackTraceInformation, // q: RTL_PROCESS_BACKTRACES
    SystemPagedPoolInformation,  // not implemented
    SystemNonPagedPoolInformation,     // not implemented
    SystemHandleInformation,           // q: SYSTEM_HANDLE_INFORMATION
    SystemObjectInformation,           // q: SYSTEM_OBJECTTYPE_INFORMATION mixed with
                                       // SYSTEM_OBJECT_INFORMATION
    SystemPageFileInformation,         // q: SYSTEM_PAGEFILE_INFORMATION
    SystemVdmInstemulInformation,      // q: SYSTEM_VDM_INSTEMUL_INFO
    SystemVdmBopInformation,           // not implemented // 20
    SystemFileCacheInformation,        // q: SYSTEM_FILECACHE_INFORMATION; s (requires
                                       // SeIncreaseQuotaPrivilege) (info for
                                       // WorkingSetTypeSystemCache)
    SystemPoolTagInformation,          // q: SYSTEM_POOLTAG_INFORMATION
    SystemInterruptInformation,        // q: SYSTEM_INTERRUPT_INFORMATION
    SystemDpcBehaviorInformation,      // q: SYSTEM_DPC_BEHAVIOR_INFORMATION; s:
                                       // SYSTEM_DPC_BEHAVIOR_INFORMATION (requires
                                       // SeLoadDriverPrivilege)
    SystemFullMemoryInformation,       // not implemented
    SystemLoadGdiDriverInformation,    // s (kernel-mode only)
    SystemUnloadGdiDriverInformation,  // s (kernel-mode only)
    SystemTimeAdjustmentInformation,   // q: SYSTEM_QUERY_TIME_ADJUST_INFORMATION; s:
                                       // SYSTEM_SET_TIME_ADJUST_INFORMATION (requires
                                       // SeSystemtimePrivilege)
    SystemSummaryMemoryInformation,    // not implemented
    SystemMirrorMemoryInformation,     // s (requires license value
                                       // "Kernel-MemoryMirroringSupported") (requires
                                       // SeShutdownPrivilege) // 30
    SystemPerformanceTraceInformation, // q; s: (type depends on
                                       // EVENT_TRACE_INFORMATION_CLASS)
    SystemObsolete0,                   // not implemented
    SystemExceptionInformation,        // q: SYSTEM_EXCEPTION_INFORMATION
    SystemCrashDumpStateInformation,   // s: SYSTEM_CRASH_DUMP_STATE_INFORMATION (requires
                                       // SeDebugPrivilege)
    SystemKernelDebuggerInformation,   // q: SYSTEM_KERNEL_DEBUGGER_INFORMATION
    SystemContextSwitchInformation,    // q: SYSTEM_CONTEXT_SWITCH_INFORMATION
    SystemRegistryQuotaInformation, // q: SYSTEM_REGISTRY_QUOTA_INFORMATION; s (requires
                                    // SeIncreaseQuotaPrivilege)
    SystemExtendServiceTableInformation,   // s (requires SeLoadDriverPrivilege) // loads
                                           // win32k only
    SystemPrioritySeperation,              // s (requires SeTcbPrivilege)
    SystemVerifierAddDriverInformation,    // s (requires SeDebugPrivilege) // 40
    SystemVerifierRemoveDriverInformation, // s (requires SeDebugPrivilege)
    SystemProcessorIdleInformation,        // q: SYSTEM_PROCESSOR_IDLE_INFORMATION
    SystemLegacyDriverInformation,         // q: SYSTEM_LEGACY_DRIVER_INFORMATION
    SystemCurrentTimeZoneInformation,      // q; s: RTL_TIME_ZONE_INFORMATION
    SystemLookasideInformation,            // q: SYSTEM_LOOKASIDE_INFORMATION
    SystemTimeSlipNotification,            // s (requires SeSystemtimePrivilege)
    SystemSessionCreate,                   // not implemented
    SystemSessionDetach,                   // not implemented
    SystemSessionInformation,              // not implemented (SYSTEM_SESSION_INFORMATION)
    SystemRangeStartInformation,           // q: SYSTEM_RANGE_START_INFORMATION // 50
    SystemVerifierInformation,             // q: SYSTEM_VERIFIER_INFORMATION; s (requires
                                           // SeDebugPrivilege)
    SystemVerifierThunkExtend,             // s (kernel-mode only)
    SystemSessionProcessInformation,       // q: SYSTEM_SESSION_PROCESS_INFORMATION
    SystemLoadGdiDriverInSystemSpace,      // s (kernel-mode only) (same as
                                           // SystemLoadGdiDriverInformation)
    SystemNumaProcessorMap,                // q
    SystemPrefetcherInformation, // q: PREFETCHER_INFORMATION; s: PREFETCHER_INFORMATION
                                 // // PfSnQueryPrefetcherInformation
    SystemExtendedProcessInformation,     // q: SYSTEM_PROCESS_INFORMATION
    SystemRecommendedSharedDataAlignment, // q
    SystemComPlusPackage,                 // q; s
    SystemNumaAvailableMemory,            // 60
    SystemProcessorPowerInformation,      // q: SYSTEM_PROCESSOR_POWER_INFORMATION
    SystemEmulationBasicInformation,
    SystemEmulationProcessorInformation,
    SystemExtendedHandleInformation,      // q: SYSTEM_HANDLE_INFORMATION_EX
    SystemLostDelayedWriteInformation,    // q: ULONG
    SystemBigPoolInformation,             // q: SYSTEM_BIGPOOL_INFORMATION
    SystemSessionPoolTagInformation,      // q: SYSTEM_SESSION_POOLTAG_INFORMATION
    SystemSessionMappedViewInformation,   // q: SYSTEM_SESSION_MAPPED_VIEW_INFORMATION
    SystemHotpatchInformation,            // q; s: SYSTEM_HOTPATCH_CODE_INFORMATION
    SystemObjectSecurityMode,             // q: ULONG // 70
    SystemWatchdogTimerHandler,           // s (kernel-mode only)
    SystemWatchdogTimerInformation,       // q (kernel-mode only); s (kernel-mode only)
    SystemLogicalProcessorInformation,    // q: SYSTEM_LOGICAL_PROCESSOR_INFORMATION
    SystemWow64SharedInformationObsolete, // not implemented
    SystemRegisterFirmwareTableInformationHandler, // s: SYSTEM_FIRMWARE_TABLE_HANDLER //
                                                   // (kernel-mode only)
    SystemFirmwareTableInformation,                // SYSTEM_FIRMWARE_TABLE_INFORMATION
    SystemModuleInformationEx,                     // q: RTL_PROCESS_MODULE_INFORMATION_EX
    SystemVerifierTriageInformation,               // not implemented
    SystemSuperfetchInformation,                   // q; s: SUPERFETCH_INFORMATION //
                                                   // PfQuerySuperfetchInformation
    SystemMemoryListInformation,  // q: SYSTEM_MEMORY_LIST_INFORMATION; s:
                                  // SYSTEM_MEMORY_LIST_COMMAND (requires
                                  // SeProfileSingleProcessPrivilege) // 80
    SystemFileCacheInformationEx, // q: SYSTEM_FILECACHE_INFORMATION; s (requires
                                  // SeIncreaseQuotaPrivilege) (same as
                                  // SystemFileCacheInformation)
    SystemThreadPriorityClientIdInformation, // s: SYSTEM_THREAD_CID_PRIORITY_INFORMATION
                                             // (requires SeIncreaseBasePriorityPrivilege)
    SystemProcessorIdleCycleTimeInformation, // q:
                                             // SYSTEM_PROCESSOR_IDLE_CYCLE_TIME_INFORMATION[]
    SystemVerifierCancellationInformation, // SYSTEM_VERIFIER_CANCELLATION_INFORMATION //
                                           // name:wow64:whNT32QuerySystemVerifierCancellationInformation
    SystemProcessorPowerInformationEx, // not implemented
    SystemRefTraceInformation,         // q; s: SYSTEM_REF_TRACE_INFORMATION //
                                       // ObQueryRefTraceInformation
    SystemSpecialPoolInformation,      // q; s: SYSTEM_SPECIAL_POOL_INFORMATION (requires
                                       // SeDebugPrivilege) // MmSpecialPoolTag, then
                                       // MmSpecialPoolCatchOverruns != 0
    SystemProcessIdInformation,        // q: SYSTEM_PROCESS_ID_INFORMATION
    SystemErrorPortInformation,        // s (requires SeTcbPrivilege)
    SystemBootEnvironmentInformation,  // q: SYSTEM_BOOT_ENVIRONMENT_INFORMATION // 90
    SystemHypervisorInformation,       // q; s (kernel-mode only)
    SystemVerifierInformationEx,       // q; s: SYSTEM_VERIFIER_INFORMATION_EX
    SystemTimeZoneInformation,         // s (requires SeTimeZonePrivilege)
    SystemImageFileExecutionOptionsInformation, // s:
                                                // SYSTEM_IMAGE_FILE_EXECUTION_OPTIONS_INFORMATION
                                                // (requires SeTcbPrivilege)
    SystemCoverageInformation, // q; s // name:wow64:whNT32QuerySystemCoverageInformation;
                               // ExpCovQueryInformation
    SystemPrefetchPatchInformation,   // SYSTEM_PREFETCH_PATCH_INFORMATION
    SystemVerifierFaultsInformation,  // s: SYSTEM_VERIFIER_FAULTS_INFORMATION (requires
                                      // SeDebugPrivilege)
    SystemSystemPartitionInformation, // q: SYSTEM_SYSTEM_PARTITION_INFORMATION
    SystemSystemDiskInformation,      // q: SYSTEM_SYSTEM_DISK_INFORMATION
    SystemProcessorPerformanceDistribution, // q:
                                            // SYSTEM_PROCESSOR_PERFORMANCE_DISTRIBUTION
                                            // // 100
    SystemNumaProximityNodeInformation,
    SystemDynamicTimeZoneInformation,          // q; s (requires SeTimeZonePrivilege)
    SystemCodeIntegrityInformation,            // q: SYSTEM_CODEINTEGRITY_INFORMATION //
                                               // SeCodeIntegrityQueryInformation
    SystemProcessorMicrocodeUpdateInformation, // s:
                                               // SYSTEM_PROCESSOR_MICROCODE_UPDATE_INFORMATION
    SystemProcessorBrandString,      // q // HaliQuerySystemInformation ->
                                     // HalpGetProcessorBrandString, info class 23
    SystemVirtualAddressInformation, // q: SYSTEM_VA_LIST_INFORMATION[]; s:
                                     // SYSTEM_VA_LIST_INFORMATION[] (requires
                                     // SeIncreaseQuotaPrivilege) //
                                     // MmQuerySystemVaInformation
    SystemLogicalProcessorAndGroupInformation, // q:
                                               // SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX
                                               // // since WIN7 //
                                               // KeQueryLogicalProcessorRelationship
    SystemProcessorCycleTimeInformation, // q: SYSTEM_PROCESSOR_CYCLE_TIME_INFORMATION[]
    SystemStoreInformation, // q; s: SYSTEM_STORE_INFORMATION // SmQueryStoreInformation
    SystemRegistryAppendString,     // s: SYSTEM_REGISTRY_APPEND_STRING_PARAMETERS // 110
    SystemAitSamplingValue,         // s: ULONG (requires SeProfileSingleProcessPrivilege)
    SystemVhdBootInformation,       // q: SYSTEM_VHD_BOOT_INFORMATION
    SystemCpuQuotaInformation,      // q; s // PsQueryCpuQuotaInformation
    SystemNativeBasicInformation,   // not implemented
    SystemErrorPortTimeouts,        // SYSTEM_ERROR_PORT_TIMEOUTS
    SystemLowPriorityIoInformation, // q: SYSTEM_LOW_PRIORITY_IO_INFORMATION
    SystemTpmBootEntropyInformation,   // q: TPM_BOOT_ENTROPY_NT_RESULT //
                                       // ExQueryTpmBootEntropyInformation
    SystemVerifierCountersInformation, // q: SYSTEM_VERIFIER_COUNTERS_INFORMATION
    SystemPagedPoolInformationEx,      // q: SYSTEM_FILECACHE_INFORMATION; s (requires
                                       // SeIncreaseQuotaPrivilege) (info for
                                       // WorkingSetTypePagedPool)
    SystemSystemPtesInformationEx,     // q: SYSTEM_FILECACHE_INFORMATION; s (requires
                                       // SeIncreaseQuotaPrivilege) (info for
                                       // WorkingSetTypeSystemPtes) // 120
    SystemNodeDistanceInformation,
    SystemAcpiAuditInformation, // q: SYSTEM_ACPI_AUDIT_INFORMATION //
                                // HaliQuerySystemInformation -> HalpAuditQueryResults,
                                // info class 26
    SystemBasicPerformanceInformation, // q: SYSTEM_BASIC_PERFORMANCE_INFORMATION //
                                       // name:wow64:whNtQuerySystemInformation_SystemBasicPerformanceInformation
    SystemQueryPerformanceCounterInformation, // q:
                                              // SYSTEM_QUERY_PERFORMANCE_COUNTER_INFORMATION
                                              // // since WIN7 SP1
    SystemSessionBigPoolInformation, // q: SYSTEM_SESSION_POOLTAG_INFORMATION // since
                                     // WIN8
    SystemBootGraphicsInformation, // q; s: SYSTEM_BOOT_GRAPHICS_INFORMATION (kernel-mode
                                   // only)
    SystemScrubPhysicalMemoryInformation, // q; s: MEMORY_SCRUB_INFORMATION
    SystemBadPageInformation,
    SystemProcessorProfileControlArea,      // q; s: SYSTEM_PROCESSOR_PROFILE_CONTROL_AREA
    SystemCombinePhysicalMemoryInformation, // s: MEMORY_COMBINE_INFORMATION,
                                            // MEMORY_COMBINE_INFORMATION_EX,
                                            // MEMORY_COMBINE_INFORMATION_EX2 // 130
    SystemEntropyInterruptTimingInformation,
    SystemConsoleInformation,                  // q: SYSTEM_CONSOLE_INFORMATION
    SystemPlatformBinaryInformation,           // q: SYSTEM_PLATFORM_BINARY_INFORMATION
    SystemPolicyInformation,                   // SYSTEM_POLICY_INFORMATION
    SystemHypervisorProcessorCountInformation, // q:
                                               // SYSTEM_HYPERVISOR_PROCESSOR_COUNT_INFORMATION
    SystemDeviceDataInformation,             // q: SYSTEM_DEVICE_DATA_INFORMATION
    SystemDeviceDataEnumerationInformation,  // q: SYSTEM_DEVICE_DATA_INFORMATION
    SystemMemoryTopologyInformation,         // q: SYSTEM_MEMORY_TOPOLOGY_INFORMATION
    SystemMemoryChannelInformation,          // q: SYSTEM_MEMORY_CHANNEL_INFORMATION
    SystemBootLogoInformation,               // q: SYSTEM_BOOT_LOGO_INFORMATION // 140
    SystemProcessorPerformanceInformationEx, // q:
                                             // SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION_EX
                                             // // since WINBLUE
    SystemCriticalProcessErrorLogInformation,
    SystemSecureBootPolicyInformation, // q: SYSTEM_SECUREBOOT_POLICY_INFORMATION
    SystemPageFileInformationEx,       // q: SYSTEM_PAGEFILE_INFORMATION_EX
    SystemSecureBootInformation,       // q: SYSTEM_SECUREBOOT_INFORMATION
    SystemEntropyInterruptTimingRawInformation,
    SystemPortableWorkspaceEfiLauncherInformation, // q:
                                                   // SYSTEM_PORTABLE_WORKSPACE_EFI_LAUNCHER_INFORMATION
    SystemFullProcessInformation, // q: SYSTEM_PROCESS_INFORMATION with
                                  // SYSTEM_PROCESS_INFORMATION_EXTENSION (requires admin)
    SystemKernelDebuggerInformationEx, // q: SYSTEM_KERNEL_DEBUGGER_INFORMATION_EX
    SystemBootMetadataInformation,     // 150
    SystemSoftRebootInformation,       // q: ULONG
    SystemElamCertificateInformation,  // s: SYSTEM_ELAM_CERTIFICATE_INFORMATION
    SystemOfflineDumpConfigInformation,
    SystemProcessorFeaturesInformation,      // q: SYSTEM_PROCESSOR_FEATURES_INFORMATION
    SystemRegistryReconciliationInformation, // s: NULL (requires admin) (flushes registry
                                             // hives)
    SystemEdidInformation,
    SystemManufacturingInformation, // q: SYSTEM_MANUFACTURING_INFORMATION // since
                                    // THRESHOLD
    SystemEnergyEstimationConfigInformation, // q:
                                             // SYSTEM_ENERGY_ESTIMATION_CONFIG_INFORMATION
    SystemHypervisorDetailInformation,    // q: SYSTEM_HYPERVISOR_DETAIL_INFORMATION
    SystemProcessorCycleStatsInformation, // q: SYSTEM_PROCESSOR_CYCLE_STATS_INFORMATION
                                          // // 160
    SystemVmGenerationCountInformation,
    SystemTrustedPlatformModuleInformation, // q: SYSTEM_TPM_INFORMATION
    SystemKernelDebuggerFlags,              // SYSTEM_KERNEL_DEBUGGER_FLAGS
    SystemCodeIntegrityPolicyInformation,   // q: SYSTEM_CODEINTEGRITYPOLICY_INFORMATION
    SystemIsolatedUserModeInformation,      // q: SYSTEM_ISOLATED_USER_MODE_INFORMATION
    SystemHardwareSecurityTestInterfaceResultsInformation,
    SystemSingleModuleInformation, // q: SYSTEM_SINGLE_MODULE_INFORMATION
    SystemAllowedCpuSetsInformation,
    SystemVsmProtectionInformation,    // q: SYSTEM_VSM_PROTECTION_INFORMATION (previously
                                       // SystemDmaProtectionInformation)
    SystemInterruptCpuSetsInformation, // q: SYSTEM_INTERRUPT_CPU_SET_INFORMATION // 170
    SystemSecureBootPolicyFullInformation, // q: SYSTEM_SECUREBOOT_POLICY_FULL_INFORMATION
    SystemCodeIntegrityPolicyFullInformation,
    SystemAffinitizedInterruptProcessorInformation,
    SystemRootSiloInformation,  // q: SYSTEM_ROOT_SILO_INFORMATION
    SystemCpuSetInformation,    // q: SYSTEM_CPU_SET_INFORMATION // since THRESHOLD2
    SystemCpuSetTagInformation, // q: SYSTEM_CPU_SET_TAG_INFORMATION
    SystemWin32WerStartCallout,
    SystemSecureKernelProfileInformation, // q:
                                          // SYSTEM_SECURE_KERNEL_HYPERGUARD_PROFILE_INFORMATION
    SystemCodeIntegrityPlatformManifestInformation, // q:
                                                    // SYSTEM_SECUREBOOT_PLATFORM_MANIFEST_INFORMATION
                                                    // // since REDSTONE
    SystemInterruptSteeringInformation, // SYSTEM_INTERRUPT_STEERING_INFORMATION_INPUT //
                                        // 180
    SystemSupportedProcessorArchitectures,
    SystemMemoryUsageInformation,              // q: SYSTEM_MEMORY_USAGE_INFORMATION
    SystemCodeIntegrityCertificateInformation, // q:
                                               // SYSTEM_CODEINTEGRITY_CERTIFICATE_INFORMATION
    SystemPhysicalMemoryInformation, // q: SYSTEM_PHYSICAL_MEMORY_INFORMATION // since
                                     // REDSTONE2
    SystemControlFlowTransition,
    SystemKernelDebuggingAllowed,         // s: ULONG
    SystemActivityModerationExeState,     // SYSTEM_ACTIVITY_MODERATION_EXE_STATE
    SystemActivityModerationUserSettings, // SYSTEM_ACTIVITY_MODERATION_USER_SETTINGS
    SystemCodeIntegrityPoliciesFullInformation,
    SystemCodeIntegrityUnlockInformation, // SYSTEM_CODEINTEGRITY_UNLOCK_INFORMATION //
                                          // 190
    SystemIntegrityQuotaInformation,
    SystemFlushInformation,             // q: SYSTEM_FLUSH_INFORMATION
    SystemProcessorIdleMaskInformation, // q: ULONG_PTR // since REDSTONE3
    SystemSecureDumpEncryptionInformation,
    SystemWriteConstraintInformation,      // SYSTEM_WRITE_CONSTRAINT_INFORMATION
    SystemKernelVaShadowInformation,       // SYSTEM_KERNEL_VA_SHADOW_INFORMATION
    SystemHypervisorSharedPageInformation, // SYSTEM_HYPERVISOR_SHARED_PAGE_INFORMATION //
                                           // since REDSTONE4
    SystemFirmwareBootPerformanceInformation,
    SystemCodeIntegrityVerificationInformation, // SYSTEM_CODEINTEGRITYVERIFICATION_INFORMATION
    SystemFirmwarePartitionInformation,    // SYSTEM_FIRMWARE_PARTITION_INFORMATION // 200
    SystemSpeculationControlInformation,   // SYSTEM_SPECULATION_CONTROL_INFORMATION //
                                           // (CVE-2017-5715) REDSTONE3 and above.
    SystemDmaGuardPolicyInformation,       // SYSTEM_DMA_GUARD_POLICY_INFORMATION
    SystemEnclaveLaunchControlInformation, // SYSTEM_ENCLAVE_LAUNCH_CONTROL_INFORMATION
    SystemWorkloadAllowedCpuSetsInformation, // SYSTEM_WORKLOAD_ALLOWED_CPU_SET_INFORMATION
                                             // // since REDSTONE5
    SystemCodeIntegrityUnlockModeInformation,
    SystemLeapSecondInformation,    // SYSTEM_LEAP_SECOND_INFORMATION
    SystemFlags2Information,        // q: SYSTEM_FLAGS_INFORMATION
    SystemSecurityModelInformation, // SYSTEM_SECURITY_MODEL_INFORMATION // since 19H1
    SystemCodeIntegritySyntheticCacheInformation,
    SystemFeatureConfigurationInformation, // SYSTEM_FEATURE_CONFIGURATION_INFORMATION //
                                           // since 20H1 // 210
    SystemFeatureConfigurationSectionInformation, // SYSTEM_FEATURE_CONFIGURATION_SECTIONS_INFORMATION
    SystemFeatureUsageSubscriptionInformation,
    SystemSecureSpeculationControlInformation, // SECURE_SPECULATION_CONTROL_INFORMATION
    // SystemSpacesBootInformation = 214,
    // SystemFwRamdiskInformation = 215,
    // SystemWheaIpmiHardwareInformation = 216,
    // SystemDifSetRuleClassInformation = 217,
    // SystemDifClearRuleClassInformation = 218,
    // SystemDifApplyPluginVerificationOnDriver = 219,
    // SystemDifRemovePluginVerificationOnDriver = 220,
    // SystemShadowStackInformation = 221, // SYSTEM_SHADOW_STACK_INFORMATION
    // SystemBuildVersionInformation = 222, // SYSTEM_BUILD_VERSION_INFORMATION
    MaxSystemInfoClass
} SYSTEM_INFORMATION_CLASS;

typedef struct _SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX {
    PVOID Object;
    ULONG_PTR UniqueProcessId;
    ULONG_PTR HandleValue;
    ULONG GrantedAccess;
    USHORT CreatorBackTraceIndex;
    USHORT ObjectTypeIndex;
    ULONG HandleAttributes;
    ULONG Reserved;
} SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX, *PSYSTEM_HANDLE_TABLE_ENTRY_INFO_EX;

typedef struct _SYSTEM_HANDLE_INFORMATION_EX {
    ULONG_PTR NumberOfHandles;
    ULONG_PTR Reserved;
    SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX Handles[1];
} SYSTEM_HANDLE_INFORMATION_EX, *PSYSTEM_HANDLE_INFORMATION_EX;

#endif
